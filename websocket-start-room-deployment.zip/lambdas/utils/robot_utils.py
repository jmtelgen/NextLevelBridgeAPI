import random
from typing import Dict, List, Optional, Tuple

def is_robot_seat(occupant: str) -> bool:
    """
    Check if a seat is occupied by a robot
    
    Args:
        occupant: The occupant of the seat (user ID or robot ID)
        
    Returns:
        bool: True if the seat is occupied by a robot
    """
    return bool(occupant) and occupant.startswith('ROBOT_')

def get_robot_id(seat: str) -> str:
    """
    Generate a robot ID for a given seat
    
    Args:
        seat: The seat position ('North', 'East', 'South', 'West')
        
    Returns:
        str: Robot ID (e.g., 'ROBOT_1')
    """
    seat_to_robot = {
        'North': 'ROBOT_1',
        'East': 'ROBOT_2', 
        'South': 'ROBOT_3',
        'West': 'ROBOT_4'
    }
    return seat_to_robot.get(seat, 'ROBOT_1')

def fill_empty_seats_with_robots(seats: Dict[str, str]) -> Dict[str, str]:
    """
    Fill empty seats with robots
    
    Args:
        seats: Current seats dictionary
        
    Returns:
        Dict[str, str]: Updated seats with robots in empty positions
    """
    updated_seats = seats.copy()
    robot_counter = 1
    
    for seat in ['North', 'East', 'South', 'West']:
        if not updated_seats.get(seat):
            updated_seats[seat] = f'ROBOT_{robot_counter}'
            robot_counter += 1
    
    return updated_seats

def get_next_seat(current_seat: str) -> str:
    """
    Get the next seat in clockwise order
    
    Args:
        current_seat: Current seat position
        
    Returns:
        str: Next seat position
    """
    seat_order = ['North', 'East', 'South', 'West']
    current_index = seat_order.index(current_seat)
    next_index = (current_index + 1) % 4
    return seat_order[next_index]

def can_start_game_with_robots(seats: Dict[str, str]) -> bool:
    """
    Check if a game can be started (at least one human player)
    
    Args:
        seats: Current seats dictionary
        
    Returns:
        bool: True if game can be started
    """
    human_players = sum(1 for occupant in seats.values() if occupant and not is_robot_seat(occupant))
    return human_players >= 1

def execute_robot_bid(room_data: Dict, robot_seat: str) -> str:
    """
    Execute a robot bid (currently always passes)
    
    Args:
        room_data: Current room data
        robot_seat: The robot's seat position
        
    Returns:
        str: The bid made by the robot
    """
    # For now, robots always pass
    return 'pass'

def execute_robot_card_play(room_data: Dict, robot_seat: str) -> str:
    """
    Execute a robot card play (plays first valid card)
    
    Args:
        room_data: Current room data
        robot_seat: The robot's seat position
        
    Returns:
        str: The card played by the robot
    """
    game_data = room_data.get('gameData', {})
    hands = game_data.get('hands', {})
    robot_hand = hands.get(robot_seat, [])
    
    if not robot_hand:
        return None
    
    current_trick = game_data.get('currentTrick', [])
    
    # If leading, play first card
    if not current_trick:
        return robot_hand[0]
    
    # If not leading, must follow suit if possible
    lead_suit = current_trick[0]['card'][1]  # Get suit of first card
    
    # Look for cards of the led suit
    led_suit_cards = [card for card in robot_hand if card[1] == lead_suit]
    
    if led_suit_cards:
        # Must follow suit - play first card of led suit
        return led_suit_cards[0]
    else:
        # Can play any card - play first card
        return robot_hand[0]

def get_robot_turns_sequence(room_data: Dict, current_seat: str) -> List[Tuple[str, str]]:
    """
    Get the sequence of robot turns that should execute immediately
    
    Args:
        room_data: Current room data
        current_seat: Current seat that just played
        
    Returns:
        List[Tuple[str, str]]: List of (seat, action_type) tuples for robot turns
    """
    robot_turns = []
    next_seat = get_next_seat(current_seat)
    seats = room_data.get('seats', {})
    game_data = room_data.get('gameData', {})
    current_phase = game_data.get('currentPhase', 'waiting')
    
    # Check consecutive robot turns
    while is_robot_seat(seats.get(next_seat, '')):
        action_type = 'bid' if current_phase == 'bidding' else 'play'
        robot_turns.append((next_seat, action_type))
        next_seat = get_next_seat(next_seat)
    
    return robot_turns

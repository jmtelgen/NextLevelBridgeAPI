from pydantic import BaseModel

class User(BaseModel):
    user_id: str
    username: str
    email: str
    passwordHash: str
    salt: str  # Required salt for enhanced security
    created_at: str 
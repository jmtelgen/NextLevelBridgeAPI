import json
import boto3
import os
from botocore.exceptions import ClientError
from utils.password_utils import PasswordUtils
from utils.jwt_utils import JWTUtils


def lambda_handler(event, context):
    """
    Lambda function to handle user login and JWT token generation
    """
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        username = body.get('username')
        password = body.get('password')
        
        # Validate input
        if not username or not password:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Missing required fields',
                    'message': 'Username and password are required'
                })
            }
        
        # Initialize DynamoDB client
        dynamodb = boto3.resource('dynamodb')
        table_name = os.environ.get('USER_TABLE', 'Users')
        table = dynamodb.Table(table_name)
        
        # Look up user by username
        try:
            response = table.get_item(
                Key={'username': username}
            )
        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Database error',
                    'message': 'Failed to retrieve user information'
                })
            }
        
        user_item = response.get('Item')
        if not user_item:
            return {
                'statusCode': 401,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Authentication failed',
                    'message': 'Invalid username or password'
                })
            }
        
        # Verify password
        stored_password_hash = user_item.get('passwordHash')
        stored_salt = user_item.get('salt')
        
        if not stored_password_hash or not stored_salt:
            return {
                'statusCode': 401,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Authentication failed',
                    'message': 'Invalid username or password'
                })
            }
        
        # Verify password using bcrypt
        if not PasswordUtils.verify_password(password, stored_password_hash, stored_salt):
            return {
                'statusCode': 401,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Authentication failed',
                    'message': 'Invalid username or password'
                })
            }
        
        # Initialize JWT utilities with AWS Secrets Manager
        try:
            jwt_utils = JWTUtils()  # Uses default "Bridge/JWT" secret ID
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Configuration error',
                    'message': f'Failed to initialize JWT utilities: {str(e)}'
                })
            }
        
        # Prepare user data for token generation
        user_data = {
            'user_id': user_item.get('user_id'),
            'username': user_item.get('username'),
            'email': user_item.get('email')
        }
        
        # Generate JWT tokens
        try:
            access_token = jwt_utils.generate_access_token(user_data, expires_in_hours=24)
            refresh_token = jwt_utils.generate_refresh_token(user_data, expires_in_days=30)
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Token generation failed',
                    'message': f'Failed to generate authentication tokens: {str(e)}'
                })
            }
        
        # Prepare response (exclude sensitive information)
        response_user = {
            'user_id': user_item.get('user_id'),
            'username': user_item.get('username'),
            'email': user_item.get('email'),
            'created_at': user_item.get('created_at')
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'POST,OPTIONS',
                'Set-Cookie': f'refresh_token={refresh_token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=2592000'  # 30 days
            },
            'body': json.dumps({
                'message': 'Login successful',
                'access_token': access_token,
                'user': response_user,
                'expires_in': 86400,  # 24 hours in seconds
                'token_type': 'Bearer'
            })
        }
        
    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'POST,OPTIONS'
            },
            'body': json.dumps({
                'error': 'Invalid JSON',
                'message': 'Request body must be valid JSON'
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'POST,OPTIONS'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': f'An unexpected error occurred: {str(e)}'
            })
        } 
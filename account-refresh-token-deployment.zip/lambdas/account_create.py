import json
import os
import uuid
import time
import boto3
from botocore.exceptions import ClientError
from utils.password_utils import PasswordUtils


def lambda_handler(event, context):
    """
    Account creation API handler with bcrypt password hashing and salt
    
    Expected request body:
    {
        "username": "user@example.com",
        "email": "user@example.com",
        "password": "plaintext_password"
    }
    
    Returns:
    {
        "user": {
            "user_id": "user_id",
            "username": "username",
            "email": "email",
            "created_at": "timestamp"
        },
        "message": "Account created successfully"
    }
    """
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        
        # Extract and validate parameters
        username = body.get('username')
        email = body.get('email')
        password = body.get('password')
        
        if not username or not email or not password:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Missing required fields',
                    'message': 'Username, email, and password are required'
                })
            }
        
        # Validate password strength
        is_valid, error_message = PasswordUtils.validate_password_strength(password)
        if not is_valid:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Invalid password',
                    'message': error_message
                })
            }
        
        # Get DynamoDB table
        table_name = os.environ.get('USER_TABLE', 'Users')
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)
        
        # Check if username already exists
        try:
            result = table.get_item(Key={'username': username})
            if result.get('Item'):
                return {
                    'statusCode': 409,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                        'Access-Control-Allow-Methods': 'POST,OPTIONS'
                    },
                    'body': json.dumps({
                        'error': 'Username already exists',
                        'message': 'An account with this username already exists'
                    })
                }
        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Database error',
                    'message': 'Failed to check username availability'
                })
            }
        
        # Generate user ID and timestamp
        user_id = str(uuid.uuid4())
        created_at = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        
        # Hash password with enhanced salt for security
        hashed_password, salt = PasswordUtils.hash_password(password)
        
        # Create user object
        user_data = {
            'user_id': user_id,
            'username': username,
            'email': email,
            'passwordHash': hashed_password,
            'salt': salt,
            'created_at': created_at
        }
        
        # Save user to database
        try:
            table.put_item(Item=user_data)
        except ClientError as e:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'POST,OPTIONS'
                },
                'body': json.dumps({
                    'error': 'Database error',
                    'message': 'Failed to create user account'
                })
            }
        
        # Create response (exclude sensitive data)
        response_user = {
            'user_id': user_data['user_id'],
            'username': user_data['username'],
            'email': user_data['email'],
            'created_at': user_data['created_at']
        }
        
        return {
            'statusCode': 201,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'POST,OPTIONS'
            },
            'body': json.dumps({
                'message': 'Account created successfully',
                'user': response_user
            })
        }
        
    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'POST,OPTIONS'
            },
            'body': json.dumps({
                'error': 'Invalid JSON',
                'message': 'Request body must be valid JSON'
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                'Access-Control-Allow-Methods': 'POST,OPTIONS'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': f'An unexpected error occurred: {str(e)}'
            })
        } 